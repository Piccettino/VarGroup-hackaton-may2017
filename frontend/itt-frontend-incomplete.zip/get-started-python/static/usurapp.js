var usurapp = angular.module('usurapp', []);

usurapp.controller('usuracontroller', ['$scope', function($scope){

    $scope.range = _.range(1, 10);

}]);
