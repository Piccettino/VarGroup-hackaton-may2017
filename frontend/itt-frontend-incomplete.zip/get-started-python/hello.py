from cloudant import Cloudant
from flask import Flask, render_template, request, jsonify
import atexit
import cf_deployment_tracker
import os
import json

# Emit Bluemix deployment event
cf_deployment_tracker.track()

app = Flask(__name__)

db_name = 'mydb'
client = None
db = None

if 'VCAP_SERVICES' in os.environ:
    vcap = json.loads(os.getenv('VCAP_SERVICES'))
    print('Found VCAP_SERVICES')
    if 'cloudantNoSQLDB' in vcap:
        creds = vcap['cloudantNoSQLDB'][0]['credentials']
        user = creds['username']
        password = creds['password']
        url = 'https://' + creds['host']
        client = Cloudant(user, password, url=url, connect=True)
        db = client.create_database(db_name, throw_on_exists=False)
elif os.path.isfile('vcap-local.json'):
    with open('vcap-local.json') as f:
        vcap = json.load(f)
        print('Found local VCAP_SERVICES')
        creds = vcap['services']['cloudantNoSQLDB'][0]['credentials']
        user = creds['username']
        password = creds['password']
        url = 'https://' + creds['host']
        client = Cloudant(user, password, url=url, connect=True)
        db = client.create_database(db_name, throw_on_exists=False)

# On Bluemix, get the port number from the environment variable PORT
# When running this app on the local machine, default the port to 8080
port = int(os.getenv('PORT', 8080))

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/usura')
def usura():
    return render_template('usura.html')

@app.route('/materiale')
def material():
    return render_template('materiale.html')

@app.route('/api/usura', methods=['POST'])
def calculate_usura():

    # Get each parameter
    usura = request.json['Usura_mat_g']
    print "--------------------------------------------"
    print request.method
    # durezzadisco = params['Durezza_Disco']
    # codpinza = params['CodPinza']
    # comprexlp = params['Comprex_LP']
    # comprexlr = params['Comprex_LR']
    # grindolp = params['Grindo_LP']
    # grindolr = params['Grindo_LR']
    # pistone = params['PistoneCpx']
    # inerzia = params['Inerzia']
    # vmax = params['Vmax']
    # areapistone = params['Area_pistone']
    # codimpianto = params['CodImpianto']
    # raggiomedio = params['Raggio_medio']
    # disco = params['Disco']


    print usura
    # print areapistone
    # Get raw materials paramters
    # n_rm = params['materiaprima'].length




    if client:
        data = {'name':request.json['name']}
        db.create_document(data)
        return 'Hello %s! I added you to the database.' % user
    else:
        print('No database')
        return 'Hello %s!' % user


@atexit.register
def shutdown():
    if client:
        client.disconnect()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)
